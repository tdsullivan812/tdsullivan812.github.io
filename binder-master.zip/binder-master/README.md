# binder

# About
Binder is a simple web template. 
It allows users to make a website by connecting a series of web pages into one home-base with a customizable navigation. Binder is built using Javascript and JQuery.

# Binder can be used with:
- Google Docs
- Tumblr
- NewHive
- PDF’s
- Wikipedia
- Youtube
- Vimeo 

# Binder can’t be used with:
- NY Times
- Twitter
- Facebook
- Github

# Questions 
Please direct any questions about Binder to: info@thisisourwork.net
